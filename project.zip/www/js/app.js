var xhr = new XMLHttpRequest();
var current;
var YOUR_APP_KEY = "YOUR_APP_KEY";
var YOUR_CLIENT_KEY = "YOUR_CLIENT_KEY";

$(function(){
    //起動時にmobile backend APIキーを設定
    NCMB.initialize(YOUR_APP_KEY,YOUR_CLIENT_KEY);
});

function rakutenTravelApi(){
var rakutentravelApi = "https://app.rakuten.co.jp/services/api/Travel/VacantHotelSearch/20131024";
    var rakutentravelKey ="Your_rakuten_applicationID";
    var RANGE = 3;
    var datumType = 1;
    navigator.geolocation.getCurrentPosition(onSuccess, onError, option);
    var lat = current.geopoint.latitude;
    var lng = current.geopoint.longitude;
    var checkInDate = new Date();
    var checkOutDate = checkInDate;
    
    checkOutDate.setDate(checkOutDate.getDate() + 1);
   var queri = rakutentravelApi + "?applicationId=" + rakutentravelKey + "&checkinDate=" + checkInDate.toISOString().substring(0,10) + "&checkoutDate=" + checkOutDate.toISOString().substring(0,10) + "&latitude=" + lat + "&longitude=" + lng + "&searchRadius=" + RANGE + "&datumType=" + datumType;
    
    // XMLHttpRequest オブジェクトを作成
   xhr.open("GET",queri,true);
   xhr.onreadystatechange = processResponse;
   xhr.send();
}

function reserve(event){

}

function processResponse() {
    if(xhr.readyState == 4) {
        if(xhr.status == 200 || xhr.status == 201) {
            // リクエストの処理
            var rakutentravel = JSON.parse(xhr.responseText);
             for(var i in rakutentravel.hotels){
                var hotelName = JSON.stringify(rakutentravel.hotels[i].hotel[0].hotelBasicInfo["hotelName"]);
                var hotelInfoUrl = JSON.stringify(rakutentravel.hotels[i].hotel[0].hotelBasicInfo["hotelInformationUrl"]);
                var clickInput = "search-button" + i;
                $("#hotel-list").append("<li>" + "<p><h3>" + hotelName + "</h3><h4>" + hotelInfoUrl + "</h4>"); 
                
                //$("#hotel-list").append("<p>" );
                $("#hotel-list").append("<h4>"+ "<input id=" + clickInput + " " + "type=" + "'button'" + "value=" + "'reserve'" +"></h4>");
                
                clickInput = "#" + clickInput ;
                $(clickInput).click({name : hotelName,url : hotelInfoUrl},reserve);
             
                $("#hotel-list").append("</p>" );
                $("#hotel-list").append("</li>" );
                $("#hotel-list").listview('refresh');           
            }
           
        } else {
            // エラー処理
        }
    }
}

function twilioTellUrl() {
    var twiliotellApi ="Your_C4SA_URL/twilio_mBaaS/twilio_mBaaS/twiliotell.php";
    console.log(twiliotellApi);
    var queri = twiliotellApi;

    //XMLHttpRequest オブジェクトを作成
    var xhr = new XMLHttpRequest();
    xhr.open("GET",queri,true);
    xhr.send();
    //出力テスト
    console.log(xhr);

    return queri;
}

function alertDismissed() {
        // 任意のコード
}

//位置情報取得に成功した場合のコールバック
var onSuccess = function(position){
    current = new CurrentPoint();
    current.distance = CurrentPoint.distance;   //検索範囲の半径を保持する    
    current.geopoint = position.coords;         //位置情報を保存する
    //search(current);
};

//位置情報取得に失敗した場合のコールバック
var onError = function(error){
    console.log("現在位置を取得できませんでした");
};

//位置情報取得時に設定するオプション
var option = {
    timeout: 6000   //タイムアウト値(ミリ秒)
};

//現在地を取得する
function find(){
    CurrentPoint.distance = 5; //検索距離を5kmに設定
    navigator.geolocation.getCurrentPosition(onSuccess, onError, option);
}

//現在地を保持するクラスを作成
function CurrentPoint(){
    geopoint=null;  //端末の位置情報を保持する
    distance=0;     //位置情報検索に利用するための検索距離を指定する
}