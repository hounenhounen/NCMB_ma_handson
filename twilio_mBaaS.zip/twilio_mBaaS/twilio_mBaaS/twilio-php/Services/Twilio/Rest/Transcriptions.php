<?php

class Services_Twilio_Rest_Transcriptions
    extends Services_Twilio_ListResource
{
}
