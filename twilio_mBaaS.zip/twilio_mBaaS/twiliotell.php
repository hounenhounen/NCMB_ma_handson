<?php
// this line loads the library 

require('./twilio-php/Services/Twilio.php'); 
 
$account_sid = 'Your_account_sid'; 
$auth_token = 'Your_auth_token'; 

$client = new Services_Twilio($account_sid, $auth_token); 
 
$client->account->calls->create('Your_tellnumber', 'Your_tellnumber', 'http://cz2rb5k-apd-app000.c4sa.net/calling.xml', array( 
	'Method' => 'GET',  
	'FallbackMethod' => 'GET',  
	'StatusCallbackMethod' => 'GET',    
	'Record' => 'false', 
));
?>